import torch
from joblib import dump, load
import torch.nn as nn
import numpy as np
import time
import torch.utils.data as Data
import torch.nn.functional as F
import matplotlib
import matplotlib.pyplot as plt
import warnings
from matplotlib import MatplotlibDeprecationWarning

matplotlib.rc("font", family='Microsoft YaHei')
warnings.filterwarnings("ignore", category=MatplotlibDeprecationWarning)

# 参数与配置
torch.manual_seed(100)  # 设置随机种子，以使实验结果具有可重复性
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")  # 有GPU先用GPU训练

# 导入模型定义
from model import TSEBG

# 加载数据集
def dataloader(batch_size, workers=2):
    # 训练集
    train_set = load('train_set')
    train_label = load('train_label')
    # 测试集
    test_set = load('test_set')
    test_label = load('test_label')

    print(train_set.size())

    # 加载数据
    train_loader = Data.DataLoader(dataset=Data.TensorDataset(train_set, train_label),
                                   batch_size=batch_size, num_workers=workers, drop_last=True)
    test_loader = Data.DataLoader(dataset=Data.TensorDataset(test_set, test_label),
                                  batch_size=batch_size, num_workers=workers, drop_last=True)
    return train_loader, test_loader


# 计算 MAE
def mean_absolute_error(y_true, y_pred):
    return np.mean(np.abs(y_true - y_pred))


# 训练模型
def model_train(train_loader, test_loader, model, parameter):
    '''
          参数
          train_loader：训练集
          test_loader：测试集
          model：模型
          parameter： 参数
          返回
      '''
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    # 参数
    epochs = parameter['epochs']
    learn_rate = parameter['learn_rate']
    patience = parameter.get('patience', 5)  # 早停机制的耐心值，默认为5

    # 定义损失函数和优化函数
    loss_function = nn.MSELoss()  # loss
    optimizer = torch.optim.Adam(model.parameters(), learn_rate)  # 优化器

    # 最低MSE
    minimum_mse = 1000.
    # 最佳模型
    best_model = model
    counter = 0  # 早停计数器

    train_mse = []  # 记录在训练集上每个epoch的 MSE 指标的变化情况   平均值
    test_mse = []  # 记录在测试集上每个epoch的 MSE 指标的变化情况   平均值

    train_mae = []  # 记录在训练集上每个epoch的 MAE 指标的变化情况   平均值
    test_mae = []  # 记录在测试集上每个epoch的 MAE 指标的变化情况   平均值

    print('*' * 20, '开始训练', '*' * 20)
    # 计算模型运行时间
    start_time = time.time()
    for epoch in range(epochs):
        # 训练
        model.train()

        train_mse_loss = []  # 保存当前epoch的MSE loss和
        train_mae_loss = []  # 保存当前epoch的MAE loss和
        for seq, labels in train_loader:
            seq, labels = seq.to(device), labels.to(device)
            # 每次更新参数前都梯度归零和初始化
            optimizer.zero_grad()
            # 前向传播
            y_pred = model(seq)  # torch.Size([16, 10])
            # 损失计算
            loss = loss_function(y_pred, labels)
            train_mse_loss.append(loss.item())  # 计算 MSE 损失
            train_mae_loss.append(mean_absolute_error(labels.cpu().numpy(), y_pred.detach().cpu().numpy()))  # 计算 MAE 损失
            # 反向传播和参数更新
            loss.backward()
            optimizer.step()

        # 计算总损失
        train_av_mseloss = np.average(train_mse_loss)  # 平均
        train_av_maeloss = np.average(train_mae_loss)
        train_mse.append(train_av_mseloss)
        train_mae.append(train_av_maeloss)

        print(f'Epoch: {epoch + 1:2} train_MSE-Loss: {train_av_mseloss:10.8f}  train_MAE-Loss: {train_av_maeloss:10.8f}')
        # 每一个epoch结束后，在验证集上验证实验结果。
        with torch.no_grad():
            # 将模型设置为评估模式
            model.eval()
            test_mse_loss = []  # 保存当前epoch的MSE loss和
            test_mae_loss = []  # 保存当前epoch的MAE loss和
            for data, label in test_loader:
                data, label = data.to(device), label.to(device)
                pre = model(data)
                # 计算损失
                test_loss = loss_function(pre, label)
                test_mse_loss.append(test_loss.item())
                test_mae_loss.append(mean_absolute_error(label.cpu().numpy(), pre.detach().cpu().numpy()))  # 计算 MAE 损失

            # 计算总损失
            test_av_mseloss = np.average(test_mse_loss)  # 平均
            test_av_maeloss = np.average(test_mae_loss)
            test_mse.append(test_av_mseloss)
            test_mae.append(test_av_maeloss)
            print(f'Epoch: {epoch + 1:2} test_MSE_Loss:{test_av_mseloss:10.8f}   test_MAE_Loss:{test_av_maeloss:10.8f}')
            # 如果当前模型的 MSE 低于于之前的最佳准确率，则更新最佳模型
            # 保存当前最优模型参数
            if test_av_mseloss < minimum_mse:
                minimum_mse = test_av_mseloss
                best_model = model  # 更新最佳模型的参数
                counter = 0  # 重置计数器
            else:
                counter += 1  # 计数器加1
                if counter >= patience:
                    print(f'Early stopping at epoch {epoch + 1}')
                    break

    print(f'\nDuration: {time.time() - start_time:.0f} seconds')
    # 最后的模型参数
    last_model = model
    print('*' * 20, '训练结束', '*' * 20)
    print(f'\nDuration: {time.time() - start_time:.0f} seconds')
    print(f'min_MSE: {minimum_mse}')

    # 可视化
    # 创建训练损失、准确率图
    plt.figure(figsize=(14, 7), dpi=100)  # dpi 越大  图片分辨率越高，写论文的话 一般建议300以上设置
    plt.plot(range(len(train_mse)), train_mse, label='训练集 MSE 损失值', marker='o', color='orange')
    plt.plot(range(len(test_mse)), test_mse, label='测试集 MSE 损失值', marker='*', color='green')
    plt.xlabel('迭代次数', fontsize=12)
    plt.ylabel('训练损失值', fontsize=12)
    plt.xticks(fontsize=10)
    plt.yticks(fontsize=10)
    plt.legend(fontsize=12)
    plt.title('TSEBG模型训练过程可视化', fontsize=16)
    # plt.show()  # 显示 lable
    plt.savefig('train_result', dpi=100)
    # 保存结果 方便 后续画图处理（如果有需要的话）
    dump(train_mse, 'train_mse')
    dump(test_mse, 'test_mse')
    dump(train_mae, 'train_mae')
    dump(test_mae, 'test_mae')
    return last_model, best_model


if __name__ == '__main__':

    batch_size = 64
    # 加载数据
    train_loader, test_loader = dataloader(batch_size)
    # 保存测试集数据， 后面进行测试
    dump(test_loader, 'test_loader')

    input_dim = 7  # 输入的特征维度
    output_dim = 1  # 输出的特征维度

    num_channels = [32, 64]  # 每个TemporalBlock中的输出通道数
    kernel_size = 3  # 卷积核大小

    dropout = 0.5  # Dropout概率

    # BiGRU 层数和维度数
    hidden_layer_sizes = [32, 64]

    # 全局注意力维度数
    attention_dim = hidden_layer_sizes[-1]  # 注意力层维度 默认为 BiGRU输出层维度
    embed_dim = 128

    # 输入数据维度为[batch_size, sequence_length, input_dim]
    # 输出维度为[batch_size, output_dim]
    # 定义 TSEBG 模型参数
    model = TSEBG(input_dim, output_dim, num_channels, kernel_size,
                                         hidden_layer_sizes, attention_dim,dropout,embed_dim)

    # 训练 参数设置
    learn_rate = 0.0003  # 学习率
    epochs = 100
    patience = 10  # 早停机制的耐心值

    # 制作参数字典
    parameter = {
        'epochs': epochs,
        'learn_rate': learn_rate,
        'patience': patience
    }

    # 训练模型
    last_model, best_model = model_train(train_loader, test_loader, model, parameter)

    # 保存最好的参数
    torch.save(best_model.state_dict(), 'best_model_TSEBG.pt')
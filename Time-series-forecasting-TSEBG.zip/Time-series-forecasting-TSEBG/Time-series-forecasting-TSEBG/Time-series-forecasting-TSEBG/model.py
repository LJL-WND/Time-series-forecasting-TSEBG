import torch
import torch.nn as nn

# 定义裁剪模块
class Chomp1d(nn.Module):
    def __init__(self, chomp_size):
        super(Chomp1d, self).__init__()
        self.chomp_size = chomp_size

    def forward(self, x):
        return x[:, :, :-self.chomp_size].contiguous()


# 定义 TCN 卷积+残差 模块
from torch.nn.utils import parametrizations

class TemporalBlock(nn.Module):
    def __init__(self, n_inputs, n_outputs, kernel_size, stride, dilation, padding, dropout=0.5):
        super(TemporalBlock, self).__init__()
        """
        params: 构成TCN的核心Block, 原作者在图中成为Residual block, 是因为它存在残差连接.
        但注意, 这个模块包含了2个Conv1d.

        n_inputs         : 输入通道数或者特征数
        n_outputs        : 输出通道数或者特征数
        kernel_size      : 卷积核大小
        stride           : 步长, 在TCN固定为1
        dilation         : 膨胀系数. 与这个Residual block(或者说, 隐藏层)所在的层数有关系. 
                            例如, 如果这个Residual block在第1层, dilation = 2**0 = 1;
                                    如果这个Residual block在第2层, dilation = 2**1 = 2;
                                    如果这个Residual block在第3层, dilation = 2**2 = 4;
                                    如果这个Residual block在第4层, dilation = 2**3 = 8 ......
        padding          : 填充系数. 与kernel_size和dilation有关
        dropout          : drop_out比率
        """
        # 第一层 卷积
        self.conv1 = parametrizations.weight_norm(nn.Conv1d(n_inputs, n_outputs, kernel_size,
                                           stride=stride, padding=padding, dilation=dilation))
        # 因为 padding 的时候, 在序列的左边和右边都有填充, 所以要裁剪
        self.chomp1 = Chomp1d(padding)
        self.relu1 = nn.ReLU()
        self.dropout1 = nn.Dropout(dropout)

        # 第二层 卷积
        self.conv2 =parametrizations.weight_norm(nn.Conv1d(n_outputs, n_outputs, kernel_size,
                                           stride=stride, padding=padding, dilation=dilation))
        self.chomp2 = Chomp1d(padding)
        self.relu2 = nn.ReLU()
        self.dropout2 = nn.Dropout(dropout)

        self.net = nn.Sequential(self.conv1, self.chomp1, self.relu1, self.dropout1,
                                 self.conv2, self.chomp2, self.relu2, self.dropout2)

        # 1×1的卷积. 只有在进入Residual block的通道数与出Residual block的通道数不一样时使用.
        # 一般都会不一样, 除非num_channels这个里面的数, 与num_inputs相等. 例如[5,5,5], 并且num_inputs也是5
        self.downsample = nn.Conv1d(n_inputs, n_outputs, 1) if n_inputs != n_outputs else None  # 进行下采样

        # 在整个Residual block中有非线性的激活
        self.relu = nn.ReLU()
        self.init_weights()

    def init_weights(self):
        self.conv1.weight.data.normal_(0, 0.01)
        self.conv2.weight.data.normal_(0, 0.01)
        if self.downsample is not None:
            self.downsample.weight.data.normal_(0, 0.01)

    def forward(self, x):
        out = self.net(x)
        res = x if self.downsample is None else self.downsample(x)
        out = out + res
        out = self.relu(out)
        return out


# 通道注意力机制
class SEBlock(nn.Module):
    def __init__(self, channel, reduction=16):
        super(SEBlock, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool1d(1)
        self.fc1 = nn.Linear(channel, channel // reduction)
        self.relu = nn.ReLU(inplace=True)
        self.fc2 = nn.Linear(channel // reduction, channel)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        # 全局平均池化  x: torch.Size([256, 128, 121])
        out = self.avg_pool(x)
        out = out.view(out.size(0), -1)
        # Squeeze阶段：通过全连接层降维
        out = self.fc1(out)
        out = self.relu(out)
        out = self.fc2(out)
        # Excitation阶段：通过Sigmoid函数生成权重
        out = self.sigmoid(out)  # out: torch.Size([256, 128])
        out = out.view(out.size(0), out.size(1), -1)
        # 乘以权重，实现通道的重新加权
        out = x * out
        return out


# 定义 Global-Attention 注意力机制
class GlobalAttention(nn.Module):
    def __init__(self, hidden_size):
        super(GlobalAttention, self).__init__()
        self.hidden_size = hidden_size
        self.attn = nn.Linear(self.hidden_size * 2, hidden_size)
        self.v = nn.Linear(hidden_size, 1, bias=False)

    def forward(self, hidden, encoder_outputs):
        max_len = encoder_outputs.size(1)
        repeated_hidden = hidden.unsqueeze(1).repeat(1, max_len, 2)
        energy = torch.tanh(self.attn(torch.cat((repeated_hidden, encoder_outputs), dim=2)))
        attention_scores = self.v(energy).squeeze(2)
        attention_weights = nn.functional.softmax(attention_scores, dim=1)
        context_vector = (encoder_outputs * attention_weights.unsqueeze(2)).sum(dim=1)
        return context_vector


class DynamicGatingFusion(nn.Module):
    def __init__(self, tcn_dim, gru_dim, output_dim):
        super(DynamicGatingFusion, self).__init__()
        self.fc_tcn = nn.Linear(tcn_dim, output_dim)
        self.fc_gru = nn.Linear(gru_dim, output_dim)
        self.gate = nn.Sequential(
            nn.Linear(tcn_dim + gru_dim, 1),
            nn.Sigmoid()
        )

    def forward(self, tcn_feat, gru_feat):
        tcn_transformed = self.fc_tcn(tcn_feat)
        gru_transformed = self.fc_gru(gru_feat)
        gate_input = torch.cat([tcn_feat, gru_feat], dim=1)
        gate_value = self.gate(gate_input)
        fused = gate_value * tcn_transformed + (1 - gate_value) * gru_transformed
        return fused


class TSEBG(nn.Module):
    def __init__(self, input_dim, output_dim, num_channels, kernel_size, hidden_layer_sizes, attention_dim,
                 dropout,embed_dim):
        super(TSEBG, self).__init__()
        """
        params:
        input_dim          : 输入数据的维度
        output_dim         : 输出维度
        num_channels       : 每个TemporalBlock中的输出通道数 
                                例如[5,12,3], 代表有3个block, 
                                block1的输出channel数量为5; 
                                block2的输出channel数量为12;
                                block3的输出channel数量为3.
        kernel_size        : 卷积核大小
        hidden_layer_sizes : BiGRU隐藏层的数目和维度
        attention_dim      : 全局注意力维度
        dropout            : drop_out比率
        """
        # TCN 时序空间特征 参数
        layers = []
        num_levels = len(num_channels)
        for i in range(num_levels):
            dilation_size = 2 ** i
            in_channels = input_dim if i == 0 else num_channels[i - 1]
            out_channels = num_channels[i]
            layers += [TemporalBlock(in_channels, out_channels, kernel_size, stride=1, dilation=dilation_size,
                                     padding=(kernel_size - 1) * dilation_size, dropout=dropout)]
            layers.append(SEBlock(out_channels))  # 添加通道注意力机制

        self.TCNnetwork = nn.Sequential(*layers)

        # 序列平局池化  为什么加这个进去，输入 [[64, 64, 7] ->[[64, 64, 1] 序列长度 做一个平均池化
        self.avgpool = nn.AdaptiveAvgPool1d(1)

        # BiGRU参数
        self.num_layers = len(hidden_layer_sizes)  # bigru层数
        self.bigru_layers = nn.ModuleList()  # 用于保存BiGRU层的列表
        # 定义第一层BiGRU
        self.bigru_layers.append(nn.GRU(input_dim, hidden_layer_sizes[0], batch_first=True, bidirectional=True))
        # 定义后续的BiGRU层
        for i in range(1, self.num_layers):
            self.bigru_layers.append(
                nn.GRU(hidden_layer_sizes[i - 1] * 2, hidden_layer_sizes[i], batch_first=True, bidirectional=True))

        # 定义 全局注意力层
        self.globalAttention = GlobalAttention(attention_dim * 2)  # 双向GRU 维度 *2

        self.fusion = DynamicGatingFusion(num_channels[-1], hidden_layer_sizes[-1] * 2, embed_dim)

        self.fc = nn.Linear(embed_dim, output_dim)

    def forward(self, input_seq):
        batch_size = input_seq.size(0)
        # input_seq [64, 12, 7])

        # 分支一：
        # 时序空间特征 提取
        # TCN-SENet 输入 （batch_size, channels, length）
        # 调换维度[B, L, D] --> [B, D, L]
        tcn_input = input_seq.permute(0, 2, 1)
        tcnSENet_features = self.TCNnetwork(tcn_input)
        # print(tcn_features.size())   # torch.Size([64, 64, 12])
        # 自适应平均池化
        tcnSENet_features = self.avgpool(tcnSENet_features)  # torch.Size([64, 64, 1])
        # 平铺
        tcnSENet_features = tcnSENet_features.reshape(batch_size, -1)  # torch.Size([64, 64])

        # 分之二：
        # 时域特征 送入BiGRU
        # 输入形状，适应网络输入[batch, seq_length, dim]
        bigru_out = input_seq
        # hidden 获取隐藏层数据
        for bigru in self.bigru_layers:
            bigru_out, hidden = bigru(bigru_out)  ## 进行一次BiGRU层的前向传播   (b, l, w)

        # 送入全局注意力层
        gatt_features = self.globalAttention(hidden[-1], bigru_out)  # torch.Size([64, 128])

        # 并行融合特征
        fused_features = self.fusion(tcnSENet_features, gatt_features)
        predict = self.fc(fused_features)
        return predict
from joblib import dump, load
import numpy as np
import torch
import torch.nn as nn
import torch.utils.data as Data
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler, MinMaxScaler

import matplotlib.pyplot as plt
import matplotlib
matplotlib.rc("font", family='Microsoft YaHei')


import warnings
from matplotlib import MatplotlibDeprecationWarning
warnings.filterwarnings("ignore", category=MatplotlibDeprecationWarning)

torch.manual_seed(100)  # 设置随机种子，以使实验结果具有可重复性
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# 导入模型定义
from model import TSEBG

# 模型 测试集 测试
def model_test(model, test_loader):
    model = model.to(device)
    # 预测数据
    original_data = []
    pre_data = []
    with torch.no_grad():
        for data, label in test_loader:
            model.eval()  # 将模型设置为评估模式
            origin_lable = label.tolist()
            original_data += origin_lable
            # 预测
            data, label = data.to(device), label.to(device)
            test_pred = model(data)  # 对测试集进行预测
            test_pred = test_pred.tolist()
            pre_data += test_pred


    # 模型分数
    original_data = np.array(original_data)
    pre_data = np.array(pre_data)
    score = r2_score(original_data, pre_data)
    print('*' * 50)
    print('TSEBG 模型分数--R^2:', score)

    print('*' * 50)
    # 测试集上的预测误差
    test_mse = mean_squared_error(original_data, pre_data)
    test_rmse = np.sqrt(test_mse)
    test_mae = mean_absolute_error(original_data, pre_data)
    print('测试数据集上的均方误差--MSE: ', test_mse)
    print('测试数据集上的均方根误差--RMSE: ', test_rmse)
    print('测试数据集上的平均绝对误差--MAE: ', test_mae)


    # 反归一化处理
    # 使用相同的均值和标准差对预测结果进行反归一化处理
    # 反标准化
    scaler = load('scaler')
    original_data = scaler.inverse_transform(original_data)
    pre_data = scaler.inverse_transform(pre_data)

    # 可视化结果
    plt.figure(figsize=(12, 4), dpi=100)
    plt.plot(original_data, label='True Data', color='red')  # 真实值
    plt.plot(pre_data, label='TSEBG', color='cornflowerblue')  # 预测值
    # plt.title('基于 TCN-SENet + BiGRU-GlobalAttention 并行预测模型', fontsize=15)
    plt.legend(loc='upper left')
    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)
    # plt.grid(True)
    plt.show()
    plt.savefig('预测拟合', dpi=100)



# 定义函数计算所有测试集样本的特征重要性并返回平均重要性
def feature_importance_all_samples(model, test_loader, input_dim):
    device = torch.device("cpu")
    model = model.to(device)
    model.eval()
    feature_importance_sum = torch.zeros(input_dim)  # 初始化特征重要性总和
    feature_importance_sum = feature_importance_sum.to(device)

    with torch.no_grad():
        for data, label in test_loader:
            data, label = data.to(device), label.to(device)
            # 前向传播获取原始输出
            original_output = model(data)

            # 针对每个特征逐个进行置零操作并重新计算输出
            for i in range(data.size(2)):  # 遍历特征维度
                # 复制输入数据
                modified_data = data.clone()
                # 将当前特征置零
                modified_data[:, :, i] = 0
                modified_data = modified_data.to(device)
                # 通过模型进行前向传播
                modified_output = model(modified_data)
                # 计算输出变化
                output_change = torch.abs(original_output - modified_output)
                # 累加特征重要性
                feature_importance_sum[i] += torch.mean(output_change)

    # 计算平均特征重要性
    feature_importance_avg = feature_importance_sum / len(test_loader)

    return feature_importance_avg

if __name__ == '__main__':

    # 模型 参数设置
    input_dim = 7  # 输入的特征维度
    output_dim = 1  # 输出的特征维度

    num_channels = [32, 64]      # 每个TemporalBlock中的输出通道数

    kernel_size = 3  # 卷积核大小
    dropout = 0.5  # Dropout概率

    # BiGRU 层数和维度数
    hidden_layer_sizes = [32, 64]

    # 全局注意力维度数
    attention_dim = hidden_layer_sizes[-1]  # 注意力层维度 默认为 BiGRU输出层维度

    # 定义 TCNSENetBiGRUGlobalAttention 模型参数
    model = TSEBG(input_dim, output_dim, num_channels, kernel_size,
                                         hidden_layer_sizes, attention_dim, dropout)


    # 加载模型
    # 加载模型的状态字典
    model.load_state_dict(torch.load('best_model_TSEBG.pt'))
    model = model.to(device)

    # 加载测试集
    test_loader = load('test_loader')

    # 模型预测
    model_test(model, test_loader)

    # 绘制 特征贡献度分析
    # 计算所有样本的特征重要性
    importance_all_samples = feature_importance_all_samples(model, test_loader, input_dim)

    # 生成示例颜色列表，可以根据需要自定义
    colors = ['dodgerblue', 'darkorange', 'seagreen', 'crimson', 'darkorchid', 'royalblue', 'g']

    # 特征名称列表
    feature_names = ['HUFL', 'HULL', 'MUFL', 'MULL', 'LUFL', 'LULL', 'OT']

    # 可视化特征重要性
    # 创建柱状图
    plt.figure(figsize=(10, 5), dpi=100)
    bars = plt.barh(range(input_dim), importance_all_samples, color=colors)
    plt.xlabel('特征贡献度')
    plt.ylabel('特征')
    plt.title('所有样本特征重要性分析')

    # 设置特征名称作为纵轴刻度和标签
    plt.yticks(range(input_dim), feature_names)

    # 显示柱状图并设置每个柱子的颜色
    for bar, color in zip(bars, colors):
        bar.set_color(color)
    plt.show()
    plt.savefig('特征重要性分析', dpi=100)
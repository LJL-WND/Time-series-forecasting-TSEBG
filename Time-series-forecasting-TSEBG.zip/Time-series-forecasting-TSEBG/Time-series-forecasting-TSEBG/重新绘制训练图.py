import matplotlib
import matplotlib.pyplot as plt
import numpy as np
from joblib import dump, load
import warnings

matplotlib.rc("font", family='Microsoft YaHei')
from matplotlib import MatplotlibDeprecationWarning
warnings.filterwarnings("ignore", category=MatplotlibDeprecationWarning)


if __name__ == '__main__':
    # 加载数据
    train_mse = load('train_mse')
    test_mse = load('test_mse')
    train_mae = load('train_mae')
    test_mae = load('test_mae')

    # 将MSE转换为RMSE
    train_rmse = np.sqrt(train_mse)
    test_rmse = np.sqrt(test_mse)

    # 打印所有epoch的RMSE
    print("所有epoch的训练集RMSE:", train_rmse)
    print("所有epoch的测试集RMSE:", test_rmse)
    print("所有epoch的训练集MAE:", train_mae)
    print("所有epoch的测试集MAE:", test_mae)


    # 创建训练损失图
    plt.figure(figsize=(14, 10), dpi=300)
    # train_mse = train_mse[:77]
    plt.plot(train_mse, label='训练集 MSE 损失值', marker='o', color='orange')
    # plt.plot(test_mse, label='测试集 MSE 损失值', marker='*', color='green')
    # plt.plot(range(len(train_mse1)), train_mse, color='b', label='train_MSE-loss')
    print(train_mse)
    print(test_mse)
    plt.xlabel('迭代次数', fontsize=12)
    plt.ylabel('训练损失值', fontsize=12)
    plt.xticks(fontsize=10)
    plt.yticks(fontsize=10)
    plt.legend(fontsize=12)
    plt.title('TSEBG模型训练过程可视化', fontsize=16)
    plt.show()
    # 保存训练图
    plt.savefig('新训练图', dpi=100)